# Mi Garaje — App de gestión de vehículos

App instalable, con tema oscuro, que funciona 100% sin conexión y guarda todo
en el propio teléfono (IndexedDB). No envía datos a ningún servidor.

## ⚠️ Sobre el .apk

No es posible compilar y firmar un `.apk` nativo sin Android Studio / conexión
a internet, así que esta app está construida como **PWA** (web app instalable).
El resultado en el móvil es idéntico a una app nativa: icono propio, pantalla
completa, funciona sin internet. Si además quieres un **archivo .apk real**
para instalarlo por USB o compartirlo, el último paso de esta guía te lo genera
gratis en 2 minutos sin tocar código.

## 📱 Hacerlo todo desde el móvil (sin ordenador)

Los archivos ya están todos sueltos (sin carpetas), así que puedes seleccionarlos
todos a la vez desde tu galería/gestor de archivos. Pasos:

1. Descarga `mi-garaje-app.zip` en el móvil y extráelo con tu gestor de
   archivos (en muchos Android, mantén pulsado el .zip → "Extraer"; si no,
   instala "ZArchiver" o "Files by Google", gratis).
2. Abre https://app.netlify.com/drop con Chrome en el móvil.
3. Toca la zona de subida (donde dice que arrastres archivos) — se abrirá el
   selector de archivos del móvil.
4. Dentro del selector, activa el modo selección múltiple (icono de "seleccionar
   varios" o mantén pulsado el primer archivo) y marca los 9 archivos
   extraídos: `index.html`, `style.css`, `app.js`, `db.js`, `manifest.json`,
   `sw.js`, `icon-192.png`, `icon-512.png`, `README.md`. Confirma.
5. Netlify los sube y te da una URL tipo `https://algo-al-azar.netlify.app`.
6. Abre esa URL con Chrome en el móvil → menú ⋮ → "Instalar aplicación".

Si el selector de tu móvil no deja marcar varios archivos a la vez, la
alternativa más fiable desde el móvil es GitHub:
1. Ve a https://github.com con Chrome, crea una cuenta gratis si no tienes.
2. Toca "+" → "New repository", ponle un nombre (ej. `mi-garaje`), créalo público.
3. Dentro del repo, "Add file" → "Upload files".
4. Toca "choose your files", selecciona los 9 archivos (multi-selección
   suele funcionar mejor aquí) y confirma la subida ("Commit changes").
5. Ve a Settings → Pages → en "Branch" elige `main` y guarda.
6. Tu URL será `https://tuusuario.github.io/mi-garaje/` (tarda 1-2 min en activarse).
7. Ábrela con Chrome en el móvil → menú ⋮ → "Instalar aplicación".

## Paso 1 — Alojar la app desde el ordenador (alternativa)

Android solo permite "Instalar app" / generar un APK desde una web servida por
**HTTPS**. Elige la opción que prefieras (gratis, sin registro complicado):

**Opción A — Netlify Drop (la más rápida, 1 minuto)**
1. Entra en https://app.netlify.com/drop desde el ordenador.
2. Arrastra la carpeta `garaje-app` (esta misma) a la web.
3. Te da una URL tipo `https://algo-al-azar.netlify.app`. Guárdala.

**Opción B — GitHub Pages**
1. Sube el contenido de esta carpeta a un repositorio de GitHub.
2. Settings → Pages → Deploy from branch → selecciona `main` / `root`.
3. Tu URL será `https://tuusuario.github.io/turepo/`.

## Paso 2 — Instalar la app en el Android

1. Abre la URL del Paso 1 con **Chrome** en el móvil.
2. Chrome mostrará un aviso "Añadir Mi Garaje a la pantalla de inicio" (o
   dentro del menú ⋮ → "Instalar aplicación"). Acepta.
3. Ya tienes el icono en tu pantalla de inicio, se abre a pantalla completa
   como una app normal y funciona sin conexión a partir de la primera vez
   que la abras.

## Paso 3 (opcional) — Generar el .apk real

1. Ve a https://www.pwabuilder.com
2. Pega la URL del Paso 1 y pulsa "Start".
3. Cuando termine el análisis, pulsa "Package for stores" → **Android**.
4. Descarga el paquete y dentro tendrás un `.apk` firmado.
5. Pásalo al móvil (o descárgalo directamente desde el móvil) y ábrelo para
   instalarlo. Android pedirá permitir "instalar apps de origen desconocido"
   la primera vez: actívalo solo para ese archivo.

## Estructura del proyecto

```
index.html    → estructura de la app
style.css     → diseño (tema oscuro, estilo automoción)
app.js        → toda la lógica (vehículos, seguros, ITV, mantenimiento, impuestos, alertas)
db.js         → guardado local con IndexedDB
manifest.json → metadatos para poder "instalar" la app
sw.js         → hace que funcione sin internet
icon-192.png  → icono de la app
icon-512.png  → icono de la app (alta resolución)
```
Todos los archivos están sueltos, sin subcarpetas, para poder subirlos fácilmente desde el móvil.

## Datos y privacidad

Todo se guarda únicamente en el almacenamiento local del navegador de tu
teléfono (IndexedDB), vehículo por vehículo, incluidas las fotos. Si
desinstalas la app o borras datos del navegador, se perderá — no hay copia
en ningún servidor. Si quieres, puedo añadirte más adelante una función de
exportar/importar copia de seguridad en un archivo.

## Funcionalidades incluidas

- Múltiples vehículos, gestión individual, tarjetas visuales con matrícula
  estilo placa española.
- **Seguro**: compañía, vencimiento, precio anual + histórico por año,
  teléfono de asistencia, cuenta domiciliada.
- **ITV**: última inspección, próxima ITV, aviso automático a mes y medio
  (45 días) vista.
- **Mantenimiento**: aceite, filtros, frenos, correa de distribución (con
  fecha/km del último cambio y del próximo previsto), reparaciones,
  historial completo cronológico, alta manual de cualquier faena.
- **Impuestos**: IVTM con checkbox de bonificación 100%, impuesto CO2,
  cuenta domiciliada.
- Alertas centralizadas en el panel principal, ordenadas por urgencia.
- Tema oscuro premium, funciona sin internet, instalable como app.
