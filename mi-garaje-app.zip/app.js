/* ============================================================
   MI GARAJE — app.js
   Todo el estado vive en IndexedDB (ver db.js). Cero llamadas de red.
   ============================================================ */

const state = { vehicles: [], currentId: null, currentTab: 'seguro' };

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

/* ---------------- utilidades ---------------- */
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }

function fmtDate(iso) {
  if (!iso) return '—';
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}
function fmtKm(n) { n = Number(n) || 0; return n.toLocaleString('es-ES') + ' km'; }
function fmtEUR(n) {
  if (n === undefined || n === null || n === '') return '—';
  return Number(n).toLocaleString('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 2 });
}
function daysUntil(iso) {
  if (!iso) return null;
  const today = new Date(); today.setHours(0,0,0,0);
  const target = new Date(iso + 'T00:00:00');
  return Math.round((target - today) / 86400000);
}
function levelForDays(days, warnWindow) {
  if (days === null) return null;
  if (days < 0) return 'danger';
  if (days <= warnWindow) return 'warn';
  return null;
}
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 2200);
}

function resizeImage(file, maxW = 900, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxW / img.width);
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/* ---------------- modelo de datos ---------------- */
function newVehicle() {
  return {
    id: uid(),
    marca: '', modelo: '', matricula: '', anio: '', km: 0, foto: null,
    seguro: { compania: '', vencimiento: '', precioAnual: '', historico: [], telefono: '', cuenta: '' },
    itv: { ultima: '', proxima: '' },
    mantenimiento: {
      aceite: { fecha: '', km: '', proximaFecha: '', proximoKm: '' },
      filtros: { fecha: '', km: '', proximaFecha: '', proximoKm: '' },
      frenos: { fecha: '', km: '', proximaFecha: '', proximoKm: '' },
      correa: { fecha: '', km: '', proximaFecha: '', proximoKm: '' },
      historial: []
    },
    impuestos: {
      ivtm: { importe: '', bonificacion100: false, fechaPago: '', cuenta: '' },
      co2: { importe: '', fechaPago: '' }
    }
  };
}

const MANT_LABELS = { aceite: 'Cambio de aceite', filtros: 'Filtros', frenos: 'Frenos', correa: 'Correa de distribución' };

/* ---------------- alertas ---------------- */
function computeVehicleAlerts(v) {
  const alerts = [];
  // ITV: aviso a mes y medio (45 días) vista
  if (v.itv.proxima) {
    const d = daysUntil(v.itv.proxima);
    const lvl = levelForDays(d, 45);
    if (lvl) alerts.push({ tab: 'itv', level: lvl, days: d,
      title: lvl === 'danger' ? 'ITV caducada' : 'Próxima ITV',
      subtitle: lvl === 'danger' ? `Venció el ${fmtDate(v.itv.proxima)}` : `En ${d} días · ${fmtDate(v.itv.proxima)}` });
  }
  // Seguro: aviso 30 días
  if (v.seguro.vencimiento) {
    const d = daysUntil(v.seguro.vencimiento);
    const lvl = levelForDays(d, 30);
    if (lvl) alerts.push({ tab: 'seguro', level: lvl, days: d,
      title: lvl === 'danger' ? 'Seguro vencido' : 'Seguro por vencer',
      subtitle: lvl === 'danger' ? `Venció el ${fmtDate(v.seguro.vencimiento)}` : `En ${d} días · ${fmtDate(v.seguro.vencimiento)}` });
  }
  // Mantenimiento
  Object.keys(MANT_LABELS).forEach((key) => {
    const item = v.mantenimiento[key];
    if (item.proximaFecha) {
      const d = daysUntil(item.proximaFecha);
      const lvl = levelForDays(d, 30);
      if (lvl) alerts.push({ tab: 'mantenimiento', level: lvl, days: d,
        title: `${MANT_LABELS[key]}${lvl === 'danger' ? ' atrasado' : ''}`,
        subtitle: lvl === 'danger' ? `Previsto el ${fmtDate(item.proximaFecha)}` : `En ${d} días · ${fmtDate(item.proximaFecha)}` });
    }
    if (item.proximoKm && v.km) {
      const restante = Number(item.proximoKm) - Number(v.km);
      if (restante <= 1000) {
        const lvl = restante < 0 ? 'danger' : 'warn';
        alerts.push({ tab: 'mantenimiento', level: lvl, days: 9999,
          title: `${MANT_LABELS[key]}${lvl === 'danger' ? ' excedido en km' : ' próximo por km'}`,
          subtitle: lvl === 'danger' ? `Superado por ${Math.abs(restante).toLocaleString('es-ES')} km` : `Quedan ${restante.toLocaleString('es-ES')} km` });
      }
    }
  });
  // Impuestos
  ['ivtm', 'co2'].forEach((key) => {
    const item = v.impuestos[key];
    if (item.fechaPago) {
      const d = daysUntil(item.fechaPago);
      const lvl = levelForDays(d, 30);
      if (lvl) alerts.push({ tab: 'impuestos', level: lvl, days: d,
        title: `${key === 'ivtm' ? 'IVTM' : 'Impuesto CO2'}${lvl === 'danger' ? ' vencido' : ' por pagar'}`,
        subtitle: lvl === 'danger' ? `Vencía el ${fmtDate(item.fechaPago)}` : `En ${d} días · ${fmtDate(item.fechaPago)}` });
    }
  });
  return alerts.sort((a, b) => a.days - b.days);
}

function worstLevel(alerts) {
  if (alerts.some(a => a.level === 'danger')) return 'danger';
  if (alerts.some(a => a.level === 'warn')) return 'warn';
  return 'ok';
}

/* ---------------- render: dashboard ---------------- */
function renderDashboard() {
  $('#dash-date').textContent = new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' });
  $('#dash-count').textContent = state.vehicles.length === 1 ? '1 vehículo en el garaje' : `${state.vehicles.length} vehículos en el garaje`;

  // alertas globales
  let allAlerts = [];
  state.vehicles.forEach(v => {
    computeVehicleAlerts(v).forEach(a => allAlerts.push({ ...a, vehicleId: v.id, vName: `${v.marca} ${v.modelo}` }));
  });
  allAlerts.sort((a, b) => a.days - b.days);
  const stripEl = $('#alerts-strip');
  stripEl.innerHTML = allAlerts.slice(0, 6).map(a => `
    <button class="alert-card ${a.level === 'danger' ? 'urgent' : ''}" data-veh="${a.vehicleId}" data-tab="${a.tab}">
      <span class="dot"></span>
      <span class="txt"><b>${a.vName} · ${a.title}</b><span>${a.subtitle}</span></span>
      <span class="chev">›</span>
    </button>`).join('');
  $$('.alert-card', stripEl).forEach(btn => btn.addEventListener('click', () => {
    openVehicle(btn.dataset.veh, btn.dataset.tab);
  }));

  // grid
  const grid = $('#vehicle-grid');
  const empty = $('#empty-state');
  if (!state.vehicles.length) {
    grid.innerHTML = ''; empty.style.display = 'block';
  } else {
    empty.style.display = 'none';
    grid.innerHTML = state.vehicles.map(v => {
      const lvl = worstLevel(computeVehicleAlerts(v));
      const statusClass = lvl === 'danger' ? 'status-danger' : lvl === 'warn' ? 'status-warn' : '';
      return `
      <article class="car-card ${statusClass}" data-id="${v.id}">
        <div class="photo-wrap">
          ${v.foto ? `<img src="${v.foto}" alt="${v.marca} ${v.modelo}">` : `<div class="no-photo">🚘 Sin foto</div>`}
          <div class="plate-chip">${plateHtml(v.matricula, true)}</div>
        </div>
        <div class="body">
          <div class="title">${v.marca || 'Marca'} ${v.modelo || ''}</div>
          <div class="subtitle">${v.anio ? 'Año ' + v.anio : 'Año sin definir'}</div>
          <div class="stats-row">
            <div class="stat-pill"><div class="v">${(Number(v.km)||0).toLocaleString('es-ES')}</div><div class="l">Km</div></div>
            <div class="stat-pill"><div class="v">${v.seguro.compania || '—'}</div><div class="l">Seguro</div></div>
            <div class="stat-pill"><div class="v">${v.itv.proxima ? fmtDate(v.itv.proxima) : '—'}</div><div class="l">ITV</div></div>
          </div>
        </div>
      </article>`;
    }).join('');
    $$('.car-card', grid).forEach(card => card.addEventListener('click', () => openVehicle(card.dataset.id)));
  }
}

function plateHtml(matricula, small) {
  const txt = matricula ? matricula.toUpperCase() : 'SIN MATRÍCULA';
  return `<span class="plate ${small ? 'sm' : ''}"><span class="eu">E</span><span class="num">${txt}</span></span>`;
}

/* ---------------- navegación ---------------- */
function openVehicle(id, tab) {
  state.currentId = id;
  state.currentTab = tab || 'seguro';
  $$('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === state.currentTab));
  renderVehicleView();
  showView('view-vehicle');
}
function showView(id) {
  $$('.view').forEach(v => v.classList.remove('active'));
  $('#' + id).classList.add('active');
  window.scrollTo(0, 0);
}
function getCurrent() { return state.vehicles.find(v => v.id === state.currentId); }

function renderVehicleView() {
  const v = getCurrent();
  if (!v) return;
  $('#veh-appbar-title').textContent = `${v.marca} ${v.modelo}`.trim() || 'Vehículo';
  $('#veh-title').textContent = `${v.marca || 'Marca'} ${v.modelo || ''}`;
  $('#veh-plate').innerHTML = plateHtml(v.matricula, true);
  $('#veh-km').textContent = (Number(v.km) || 0).toLocaleString('es-ES');
  $('#veh-anio').textContent = v.anio || '—';

  const heroPhoto = $('#hero-photo');
  heroPhoto.querySelector('.no-photo') && heroPhoto.querySelector('.no-photo').remove();
  const existingImg = heroPhoto.querySelector('img');
  if (v.foto) {
    if (existingImg) existingImg.src = v.foto;
    else heroPhoto.insertAdjacentHTML('afterbegin', `<img src="${v.foto}" alt="foto vehículo">`);
  } else {
    if (existingImg) existingImg.remove();
    heroPhoto.insertAdjacentHTML('afterbegin', `<div class="no-photo">🚘 Sin foto</div>`);
  }

  renderTabPanel(v);
}

function renderTabPanel(v) {
  $$('.tab-panel').forEach(p => p.classList.remove('active'));
  $('#panel-' + state.currentTab).classList.add('active');
  renderSeguro(v);
  renderITV(v);
  renderMantenimiento(v);
  renderImpuestos(v);
}

/* ---------------- SEGURO ---------------- */
function renderSeguro(v) {
  const s = v.seguro;
  const d = daysUntil(s.vencimiento);
  const lvl = levelForDays(d, 30);
  const badge = !s.vencimiento ? '' : lvl === 'danger'
    ? `<span class="badge danger">Vencido</span>` : lvl === 'warn'
    ? `<span class="badge warn">Vence en ${d} días</span>` : `<span class="badge ok">Al día</span>`;

  $('#panel-seguro').innerHTML = `
    <div class="section-card">
      <div class="sc-head"><h3>Póliza</h3><button class="edit-link" id="edit-seguro">Editar</button></div>
      <div class="kv"><span class="k">Compañía</span><span class="v">${s.compania || '—'}</span></div>
      <div class="kv"><span class="k">Vencimiento</span><span class="v">${fmtDate(s.vencimiento)} ${badge}</span></div>
      <div class="kv"><span class="k">Precio anual</span><span class="v">${fmtEUR(s.precioAnual)}</span></div>
      <div class="kv"><span class="k">Asistencia en carretera</span><span class="v">${s.telefono || '—'}</span></div>
      <div class="kv"><span class="k">Cuenta domiciliada</span><span class="v">${s.cuenta || '—'}</span></div>
    </div>
    <div class="section-card">
      <div class="sc-head"><h3>Histórico de precios</h3><button class="edit-link" id="add-precio">+ Añadir año</button></div>
      ${s.historico.length ? s.historico.slice().sort((a,b)=>b.anio-a.anio).map(h => `
        <div class="price-row"><span class="yr">${h.anio}</span><span>${fmtEUR(h.precio)}</span></div>`).join('')
        : `<div class="kv"><span class="k">Sin registros todavía</span></div>`}
    </div>`;

  $('#edit-seguro').addEventListener('click', () => formEditSeguro(v));
  $('#add-precio').addEventListener('click', () => formAddHistoricoPrecio(v));
}

/* ---------------- ITV ---------------- */
function renderITV(v) {
  const it = v.itv;
  const d = daysUntil(it.proxima);
  const lvl = levelForDays(d, 45);
  const badge = !it.proxima ? '' : lvl === 'danger'
    ? `<span class="badge danger">Caducada</span>` : lvl === 'warn'
    ? `<span class="badge warn">Aviso: en ${d} días</span>` : `<span class="badge ok">Al día</span>`;

  $('#panel-itv').innerHTML = `
    <div class="section-card">
      <div class="sc-head"><h3>Inspección técnica</h3><button class="edit-link" id="edit-itv">Editar</button></div>
      <div class="kv"><span class="k">Última inspección</span><span class="v">${fmtDate(it.ultima)}</span></div>
      <div class="kv"><span class="k">Próxima ITV</span><span class="v">${fmtDate(it.proxima)} ${badge}</span></div>
    </div>
    <div class="hint">Recibirás un aviso en el garaje cuando falte mes y medio (45 días) para la próxima ITV.</div>`;

  $('#edit-itv').addEventListener('click', () => formEditITV(v));
}

/* ---------------- MANTENIMIENTO ---------------- */
function mantBadge(item) {
  let dLevel = null, dDays = null;
  if (item.proximaFecha) { dDays = daysUntil(item.proximaFecha); dLevel = levelForDays(dDays, 30); }
  if (!item.fecha && !item.proximaFecha && !item.proximoKm) return `<span class="badge" style="background:var(--surface-2);color:var(--text-mute)">Sin datos</span>`;
  if (dLevel === 'danger') return `<span class="badge danger">Atrasado</span>`;
  if (dLevel === 'warn') return `<span class="badge warn">En ${dDays} días</span>`;
  return `<span class="badge ok">Al día</span>`;
}

function renderMantenimiento(v) {
  const m = v.mantenimiento;
  const items = Object.keys(MANT_LABELS).map(key => {
    const it = m[key];
    return `
      <div class="section-card">
        <div class="sc-head"><h3>${MANT_LABELS[key]}</h3><button class="edit-link" data-key="${key}">Editar</button></div>
        <div class="kv"><span class="k">Último cambio</span><span class="v">${fmtDate(it.fecha)}${it.km ? ' · ' + fmtKm(it.km) : ''}</span></div>
        <div class="kv"><span class="k">Próximo</span><span class="v">${it.proximaFecha ? fmtDate(it.proximaFecha) : '—'}${it.proximoKm ? ' · ' + fmtKm(it.proximoKm) : ''} ${mantBadge(it)}</span></div>
      </div>`;
  }).join('');

  const historial = m.historial.slice().sort((a, b) => (b.fecha || '').localeCompare(a.fecha || ''));

  $('#panel-mantenimiento').innerHTML = `
    ${items}
    <div class="section-card">
      <div class="sc-head"><h3>Historial completo</h3><button class="edit-link" id="add-hist">+ Añadir faena</button></div>
      ${historial.length ? historial.map(h => `
        <div class="hist-item">
          <div class="dot-col"><div class="d"></div><div class="line"></div></div>
          <div class="hi-body">
            <div class="hi-title">${h.tipo}</div>
            <div class="hi-meta">${fmtDate(h.fecha)} ${h.km ? '· ' + fmtKm(h.km) : ''} ${h.coste ? '· ' + fmtEUR(h.coste) : ''}</div>
            ${h.descripcion ? `<div class="hi-desc">${escapeHtml(h.descripcion)}</div>` : ''}
          </div>
        </div>`).join('') : `<div class="kv"><span class="k">Aún no hay faenas registradas</span></div>`}
    </div>`;

  $$('[data-key]', $('#panel-mantenimiento')).forEach(btn => {
    btn.addEventListener('click', () => formEditMantItem(v, btn.dataset.key));
  });
  $('#add-hist').addEventListener('click', () => formAddHistorial(v));
}

function escapeHtml(s) { return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

/* ---------------- IMPUESTOS ---------------- */
function renderImpuestos(v) {
  const t = v.impuestos;
  $('#panel-impuestos').innerHTML = `
    <div class="section-card">
      <div class="sc-head"><h3>IVTM · Circulación</h3><button class="edit-link" id="edit-ivtm">Editar</button></div>
      <div class="kv"><span class="k">Bonificación 100%</span><span class="v">${t.ivtm.bonificacion100 ? '<span class="badge ok">Sí</span>' : 'No'}</span></div>
      <div class="kv"><span class="k">Importe</span><span class="v">${t.ivtm.bonificacion100 ? fmtEUR(0) : fmtEUR(t.ivtm.importe)}</span></div>
      <div class="kv"><span class="k">Fecha de pago</span><span class="v">${fmtDate(t.ivtm.fechaPago)}</span></div>
      <div class="kv"><span class="k">Cuenta domiciliada</span><span class="v">${t.ivtm.cuenta || '—'}</span></div>
    </div>
    <div class="section-card">
      <div class="sc-head"><h3>Impuesto CO2</h3><button class="edit-link" id="edit-co2">Editar</button></div>
      <div class="kv"><span class="k">Importe</span><span class="v">${fmtEUR(t.co2.importe)}</span></div>
      <div class="kv"><span class="k">Fecha de pago</span><span class="v">${fmtDate(t.co2.fechaPago)}</span></div>
    </div>`;
  $('#edit-ivtm').addEventListener('click', () => formEditIVTM(v));
  $('#edit-co2').addEventListener('click', () => formEditCO2(v));
}

/* ---------------- guardado ---------------- */
async function saveVehicle(v) {
  await GarajeDB.put(v);
  const idx = state.vehicles.findIndex(x => x.id === v.id);
  if (idx >= 0) state.vehicles[idx] = v; else state.vehicles.push(v);
}

/* ---------------- bottom sheet genérico ---------------- */
function openSheet(title, bodyHtml) {
  $('#sheet-content').innerHTML = `<div class="grabber"></div><h2>${title}</h2>${bodyHtml}`;
  $('#overlay').classList.add('open');
}
function closeSheet() { $('#overlay').classList.remove('open'); }
$('#overlay').addEventListener('click', (e) => { if (e.target.id === 'overlay') closeSheet(); });

function submitRow(label = 'Guardar') {
  return `<div class="btn-row" style="margin-top:18px">
    <button type="button" class="btn btn-ghost" id="sheet-cancel">Cancelar</button>
    <button type="submit" class="btn btn-primary">${label}</button>
  </div>`;
}

/* ---------------- FORM: añadir / editar datos generales ---------------- */
function formAddVehicle() {
  const v = newVehicle();
  formEditGeneral(v, true);
}
function formEditGeneral(v, isNew) {
  openSheet(isNew ? 'Añadir vehículo' : 'Editar datos', `
    <form id="f-general">
      <div class="photo-picker ${v.foto ? 'has-photo' : ''}" id="fg-photo-picker">
        ${v.foto ? `<img src="${v.foto}">` : ''}
        <span class="lbl">📷 Toca para añadir una foto</span>
      </div>
      <div class="field-row">
        <div class="field"><label>Marca</label><input type="text" id="fg-marca" value="${v.marca}" placeholder="Volkswagen" required></div>
        <div class="field"><label>Modelo</label><input type="text" id="fg-modelo" value="${v.modelo}" placeholder="Golf" required></div>
      </div>
      <div class="field"><label>Matrícula</label><input type="text" id="fg-matricula" value="${v.matricula}" placeholder="0000 ABC" style="text-transform:uppercase"></div>
      <div class="field-row">
        <div class="field"><label>Año</label><input type="number" id="fg-anio" value="${v.anio}" placeholder="2021" min="1950" max="2100"></div>
        <div class="field"><label>Kilómetros actuales</label><input type="number" id="fg-km" value="${v.km}" placeholder="45000" min="0"></div>
      </div>
      ${submitRow(isNew ? 'Añadir al garaje' : 'Guardar cambios')}
    </form>`);

  let pendingPhoto = v.foto;
  $('#fg-photo-picker').addEventListener('click', () => {
    $('#file-input').onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      pendingPhoto = await resizeImage(file);
      const picker = $('#fg-photo-picker');
      picker.classList.add('has-photo');
      picker.innerHTML = `<img src="${pendingPhoto}"><span class="lbl">📷 Toca para añadir una foto</span>`;
    };
    $('#file-input').click();
  });

  $('#sheet-cancel').addEventListener('click', closeSheet);
  $('#f-general').addEventListener('submit', async (e) => {
    e.preventDefault();
    v.marca = $('#fg-marca').value.trim();
    v.modelo = $('#fg-modelo').value.trim();
    v.matricula = $('#fg-matricula').value.trim().toUpperCase();
    v.anio = $('#fg-anio').value;
    v.km = $('#fg-km').value || 0;
    v.foto = pendingPhoto;
    await saveVehicle(v);
    closeSheet();
    if (isNew) { renderDashboard(); toast('Vehículo añadido al garaje'); openVehicle(v.id); }
    else { renderVehicleView(); renderDashboard(); toast('Datos actualizados'); }
  });
}

function editPhotoDirect(v) {
  $('#file-input').onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    v.foto = await resizeImage(file);
    await saveVehicle(v);
    renderVehicleView(); renderDashboard();
    toast('Foto actualizada');
  };
  $('#file-input').click();
}

/* ---------------- FORM: seguro ---------------- */
function formEditSeguro(v) {
  const s = v.seguro;
  openSheet('Seguro del vehículo', `
    <form id="f-seguro">
      <div class="field"><label>Compañía aseguradora</label><input type="text" id="fs-compania" value="${s.compania}" placeholder="Mapfre, Mutua..."></div>
      <div class="field-row">
        <div class="field"><label>Fecha de vencimiento</label><input type="date" id="fs-venc" value="${s.vencimiento}"></div>
        <div class="field"><label>Precio anual (€)</label><input type="number" step="0.01" id="fs-precio" value="${s.precioAnual}" placeholder="620"></div>
      </div>
      <div class="field"><label>Teléfono asistencia en carretera</label><input type="tel" id="fs-tel" value="${s.telefono}" placeholder="900 100 200"></div>
      <div class="field"><label>Cuenta domiciliada</label><input type="text" id="fs-cuenta" value="${s.cuenta}" placeholder="ES00 0000 0000 0000 0000"></div>
      ${submitRow()}
    </form>`);
  $('#sheet-cancel').addEventListener('click', closeSheet);
  $('#f-seguro').addEventListener('submit', async (e) => {
    e.preventDefault();
    s.compania = $('#fs-compania').value.trim();
    s.vencimiento = $('#fs-venc').value;
    s.precioAnual = $('#fs-precio').value;
    s.telefono = $('#fs-tel').value.trim();
    s.cuenta = $('#fs-cuenta').value.trim();
    await saveVehicle(v);
    closeSheet(); renderVehicleView(); renderDashboard(); toast('Seguro actualizado');
  });
}

function formAddHistoricoPrecio(v) {
  openSheet('Añadir precio histórico', `
    <form id="f-hist-precio">
      <div class="field-row">
        <div class="field"><label>Año</label><input type="number" id="fhp-anio" value="${new Date().getFullYear()}" required></div>
        <div class="field"><label>Precio (€)</label><input type="number" step="0.01" id="fhp-precio" required></div>
      </div>
      ${submitRow('Añadir')}
    </form>`);
  $('#sheet-cancel').addEventListener('click', closeSheet);
  $('#f-hist-precio').addEventListener('submit', async (e) => {
    e.preventDefault();
    v.seguro.historico.push({ anio: Number($('#fhp-anio').value), precio: Number($('#fhp-precio').value) });
    await saveVehicle(v);
    closeSheet(); renderVehicleView(); toast('Precio añadido al histórico');
  });
}

/* ---------------- FORM: ITV ---------------- */
function formEditITV(v) {
  const it = v.itv;
  openSheet('Inspección técnica (ITV)', `
    <form id="f-itv">
      <div class="field"><label>Fecha última inspección</label><input type="date" id="fi-ultima" value="${it.ultima}"></div>
      <div class="field"><label>Próxima ITV</label><input type="date" id="fi-proxima" value="${it.proxima}"></div>
      <div class="hint">Se generará un aviso automático cuando falte mes y medio para esta fecha.</div>
      ${submitRow()}
    </form>`);
  $('#sheet-cancel').addEventListener('click', closeSheet);
  $('#f-itv').addEventListener('submit', async (e) => {
    e.preventDefault();
    it.ultima = $('#fi-ultima').value;
    it.proxima = $('#fi-proxima').value;
    await saveVehicle(v);
    closeSheet(); renderVehicleView(); renderDashboard(); toast('ITV actualizada');
  });
}

/* ---------------- FORM: mantenimiento (editar próximo/último de un ítem) ---------------- */
function formEditMantItem(v, key) {
  const it = v.mantenimiento[key];
  openSheet(MANT_LABELS[key], `
    <form id="f-mant">
      <div class="field-row">
        <div class="field"><label>Fecha último cambio</label><input type="date" id="fm-fecha" value="${it.fecha}"></div>
        <div class="field"><label>Km en ese momento</label><input type="number" id="fm-km" value="${it.km}"></div>
      </div>
      <div class="field-row">
        <div class="field"><label>Próxima fecha prevista</label><input type="date" id="fm-pfecha" value="${it.proximaFecha}"></div>
        <div class="field"><label>Próximo km previsto</label><input type="number" id="fm-pkm" value="${it.proximoKm}"></div>
      </div>
      <div class="hint">Recibirás aviso 30 días antes de la fecha, o cuando falten 1.000 km.</div>
      ${submitRow()}
    </form>`);
  $('#sheet-cancel').addEventListener('click', closeSheet);
  $('#f-mant').addEventListener('submit', async (e) => {
    e.preventDefault();
    it.fecha = $('#fm-fecha').value;
    it.km = $('#fm-km').value;
    it.proximaFecha = $('#fm-pfecha').value;
    it.proximoKm = $('#fm-pkm').value;
    await saveVehicle(v);
    closeSheet(); renderVehicleView(); renderDashboard(); toast('Mantenimiento actualizado');
  });
}

/* ---------------- FORM: añadir faena al historial ---------------- */
function formAddHistorial(v) {
  const tipos = ['Cambio de aceite', 'Filtros', 'Frenos', 'Correa de distribución', 'Reparación', 'Revisión', 'Otro'];
  let tipoSel = tipos[0];
  openSheet('Añadir faena realizada', `
    <form id="f-hist">
      <div class="seg" id="seg-tipo">${tipos.map(t => `<button type="button" data-t="${t}" class="${t===tipoSel?'active':''}">${t}</button>`).join('')}</div>
      <div class="field-row">
        <div class="field"><label>Fecha</label><input type="date" id="fh-fecha" required></div>
        <div class="field"><label>Km</label><input type="number" id="fh-km" placeholder="52000"></div>
      </div>
      <div class="field"><label>Coste (€)</label><input type="number" step="0.01" id="fh-coste" placeholder="Opcional"></div>
      <div class="field"><label>Descripción</label><textarea id="fh-desc" placeholder="Detalles del trabajo realizado..."></textarea></div>
      ${submitRow('Guardar en historial')}
    </form>`);
  $$('#seg-tipo button').forEach(b => b.addEventListener('click', () => {
    tipoSel = b.dataset.t;
    $$('#seg-tipo button').forEach(x => x.classList.toggle('active', x === b));
  }));
  $('#sheet-cancel').addEventListener('click', closeSheet);
  $('#f-hist').addEventListener('submit', async (e) => {
    e.preventDefault();
    v.mantenimiento.historial.push({
      id: uid(), tipo: tipoSel, fecha: $('#fh-fecha').value,
      km: $('#fh-km').value, coste: $('#fh-coste').value, descripcion: $('#fh-desc').value.trim()
    });
    // si coincide con un ítem estándar, actualizamos también su "último cambio"
    const map = { 'Cambio de aceite': 'aceite', 'Filtros': 'filtros', 'Frenos': 'frenos', 'Correa de distribución': 'correa' };
    if (map[tipoSel]) {
      v.mantenimiento[map[tipoSel]].fecha = $('#fh-fecha').value;
      if ($('#fh-km').value) v.mantenimiento[map[tipoSel]].km = $('#fh-km').value;
    }
    await saveVehicle(v);
    closeSheet(); renderVehicleView(); renderDashboard(); toast('Faena añadida al historial');
  });
}

/* ---------------- FORM: impuestos ---------------- */
function formEditIVTM(v) {
  const t = v.impuestos.ivtm;
  openSheet('IVTM · Impuesto de circulación', `
    <form id="f-ivtm">
      <div class="check-row"><input type="checkbox" id="fx-bonif" ${t.bonificacion100 ? 'checked' : ''}><label for="fx-bonif">Bonificación del 100%</label></div>
      <div class="field"><label>Importe (€)</label><input type="number" step="0.01" id="fx-importe" value="${t.importe}" ${t.bonificacion100 ? 'disabled' : ''}></div>
      <div class="field"><label>Fecha de pago</label><input type="date" id="fx-fecha" value="${t.fechaPago}"></div>
      <div class="field"><label>Cuenta domiciliada</label><input type="text" id="fx-cuenta" value="${t.cuenta}" placeholder="ES00 0000 0000 0000 0000"></div>
      ${submitRow()}
    </form>`);
  $('#fx-bonif').addEventListener('change', (e) => { $('#fx-importe').disabled = e.target.checked; });
  $('#sheet-cancel').addEventListener('click', closeSheet);
  $('#f-ivtm').addEventListener('submit', async (e) => {
    e.preventDefault();
    t.bonificacion100 = $('#fx-bonif').checked;
    t.importe = $('#fx-importe').value;
    t.fechaPago = $('#fx-fecha').value;
    t.cuenta = $('#fx-cuenta').value.trim();
    await saveVehicle(v);
    closeSheet(); renderVehicleView(); renderDashboard(); toast('IVTM actualizado');
  });
}
function formEditCO2(v) {
  const t = v.impuestos.co2;
  openSheet('Impuesto CO2', `
    <form id="f-co2">
      <div class="field"><label>Importe (€)</label><input type="number" step="0.01" id="fc-importe" value="${t.importe}"></div>
      <div class="field"><label>Fecha de pago</label><input type="date" id="fc-fecha" value="${t.fechaPago}"></div>
      ${submitRow()}
    </form>`);
  $('#sheet-cancel').addEventListener('click', closeSheet);
  $('#f-co2').addEventListener('submit', async (e) => {
    e.preventDefault();
    t.importe = $('#fc-importe').value;
    t.fechaPago = $('#fc-fecha').value;
    await saveVehicle(v);
    closeSheet(); renderVehicleView(); renderDashboard(); toast('Impuesto CO2 actualizado');
  });
}

/* ---------------- eliminar vehículo ---------------- */
function confirmDeleteVehicle(v) {
  openSheet('Eliminar vehículo', `
    <p style="color:var(--text-dim); font-size:14px; line-height:1.5;">
      Se eliminará <b>${v.marca} ${v.modelo}</b> y todos sus datos (seguro, ITV, mantenimiento e impuestos) de este teléfono. Esta acción no se puede deshacer.
    </p>
    <div class="btn-row" style="margin-top:16px">
      <button type="button" class="btn btn-ghost" id="sheet-cancel">Cancelar</button>
      <button type="button" class="btn btn-danger-ghost" id="btn-confirm-delete">Eliminar</button>
    </div>`);
  $('#sheet-cancel').addEventListener('click', closeSheet);
  $('#btn-confirm-delete').addEventListener('click', async () => {
    await GarajeDB.delete(v.id);
    state.vehicles = state.vehicles.filter(x => x.id !== v.id);
    closeSheet();
    showView('view-dashboard');
    renderDashboard();
    toast('Vehículo eliminado');
  });
}

/* ---------------- eventos globales ---------------- */
$('#btn-add-vehicle').addEventListener('click', formAddVehicle);
$('#btn-back').addEventListener('click', () => { showView('view-dashboard'); renderDashboard(); });
$('#btn-edit-general').addEventListener('click', () => formEditGeneral(getCurrent(), false));
$('#btn-edit-photo').addEventListener('click', () => editPhotoDirect(getCurrent()));
$('#btn-delete-vehicle').addEventListener('click', () => confirmDeleteVehicle(getCurrent()));
$('#btn-info').addEventListener('click', () => {
  openSheet('Acerca de Mi Garaje', `
    <p style="color:var(--text-dim); font-size:14px; line-height:1.6;">
      Todos tus vehículos y sus datos se guardan únicamente en este teléfono (IndexedDB local). Nada se envía a internet.
      La app funciona sin conexión y puede instalarse en la pantalla de inicio.
    </p>
    <div class="btn-row" style="margin-top:16px"><button type="button" class="btn btn-primary" id="sheet-cancel">Entendido</button></div>`);
  $('#sheet-cancel').addEventListener('click', closeSheet);
});

$$('.tab-btn').forEach(btn => btn.addEventListener('click', () => {
  state.currentTab = btn.dataset.tab;
  $$('.tab-btn').forEach(b => b.classList.toggle('active', b === btn));
  renderTabPanel(getCurrent());
}));

/* ---------------- instalación PWA ---------------- */
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  $('#install-banner').style.display = 'flex';
});
$('#btn-install').addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  $('#install-banner').style.display = 'none';
});
window.addEventListener('appinstalled', () => { $('#install-banner').style.display = 'none'; });

/* ---------------- arranque ---------------- */
async function boot() {
  state.vehicles = await GarajeDB.getAll();
  renderDashboard();
  if ('serviceWorker' in navigator) {
    try { await navigator.serviceWorker.register('sw.js'); } catch (err) { console.warn('SW no registrado', err); }
  }
}
boot();
